<div
	class="message border w-32 h-16 flex justify-center items-center rounded-md py-1 px-2.5 my-0.25 break-all self-start bg-gray-400 text-white"
>
	<div
		class="animate-spin inline-block w-8 h-8 border-[3px] border-current border-t-transparent text-white-600 rounded-full"
		role="status"
		aria-label="loading"
	/>
</div>

<style>
	.message {
		min-height: 60px;
	}
</style>
